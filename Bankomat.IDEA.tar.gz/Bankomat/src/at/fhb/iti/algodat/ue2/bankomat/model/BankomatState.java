package at.fhb.iti.algodat.ue2.bankomat.model;

public enum BankomatState {
	// TODO Rename States
	AVAILABLE,
	STATE1,
	STATE2,
	STATE3;
}
