package at.fhb.iti.algodat.balls;

import at.fhb.iti.algodat.balls.balls.BasicBallRectangle;

public class BallRectangle extends BasicBallRectangle {

	// TODO fields

	public BallRectangle(int d, int e, int f, int g) {
		super(d,e,f,g);
	}

	public synchronized void occupy() {
		// TODO occupy()
	}

	public synchronized void free() {
		// TODO free()
	}


}
