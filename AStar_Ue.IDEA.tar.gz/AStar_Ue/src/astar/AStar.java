package astar;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import modelcontroller.DrawModel;
import modelcontroller.commands.DrawModelResetCommand;
import shapes.Shape;
import shapes.ShapeLine;
import shapes.ShapePoint;


public class AStar {

	public static void calculate(List<ShapeLine> lineList, Set<ShapePoint> pointSet, ShapePoint startPoint, ShapePoint endPoint) {
		
		Set<ShapePoint> closedList = new HashSet<ShapePoint>();
		Set<ShapePoint> openList = new HashSet<ShapePoint>();
		
		////////////////////////////////////////////////////////
		// Delete this and replace by algorithm
		
		ArrayList<Shape> myShapeList = new ArrayList<Shape>();
		myShapeList.addAll(lineList);
		myShapeList.addAll(pointSet);
		
		myShapeList.remove(startPoint);
		myShapeList.remove(endPoint);
				
		Collections.shuffle(myShapeList);
		
		for (Shape x : myShapeList) {
			x.blink();
			x.setColor(Color.MAGENTA);
		}

		////////////////////////////////////////////////////////
		
	}
		
	
	private static void savesetColor(ShapePoint point, ShapePoint startPoint, ShapePoint endPoint, Color color) {
		if ( ! point.equals(startPoint) && ! point.equals(endPoint) ) point.setColor(color); 
		
	}


	private static void colorPath(ShapePoint end, Color c) {
		if (end.getRoute() != null) {
			end.getRoute().setColor(c);
			colorPath(end.getRoute().traverse(end), c);
		}
	}


	private static double pathLength(ShapePoint end) {
		if (end.getRoute() == null) return 0;
		else return end.getRoute().length() + pathLength(end.getRoute().traverse(end));
	}


	private static ShapePoint findMininalPoint(Set<ShapePoint> openList) {
		ShapePoint minimalPoint = null;
		for (ShapePoint x : openList) {
			if (x.getHeuristics() != 0.0) {
				if  (minimalPoint == null) minimalPoint = x;
				else if (minimalPoint.getHeuristics() > x.getHeuristics()) minimalPoint = x;
			}
		}
		return minimalPoint;
	}

}
