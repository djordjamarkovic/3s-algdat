package astar;

public class Definitions {

	public static final long BlinkDelay = 300;  // in milliseconds

}
