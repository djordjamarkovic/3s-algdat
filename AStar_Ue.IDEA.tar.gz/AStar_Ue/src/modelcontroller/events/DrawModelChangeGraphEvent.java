package modelcontroller.events;

import modelcontroller.DrawViewDataSupplier;

public class DrawModelChangeGraphEvent extends DrawModelChangeEvent {

	public DrawModelChangeGraphEvent(DrawViewDataSupplier m) {
		super(m);
	}

}
