package modelcontroller.commands;


public class DrawModelNullCommand extends DrawModelCommand {

	public DrawModelNullCommand() {
		super();
	}
	
}
