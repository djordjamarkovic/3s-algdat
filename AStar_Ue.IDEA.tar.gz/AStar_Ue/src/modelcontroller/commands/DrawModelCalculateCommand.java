package modelcontroller.commands;

public class DrawModelCalculateCommand extends DrawModelCommand {

}
