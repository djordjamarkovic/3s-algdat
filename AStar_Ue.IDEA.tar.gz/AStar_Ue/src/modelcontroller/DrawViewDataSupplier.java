package modelcontroller;

import java.util.List;

import shapes.Shape;

public interface DrawViewDataSupplier {

	public List<Shape> getShapes();
	
}
